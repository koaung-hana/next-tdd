'use client'

export default function ClientComponent() {
  return <h1>Client Component</h1>
}
